<?php
/*
Plugin Name: Image Alt Description
Description: Automatically Search for images without alt descriptions and easily add the missing alt tags. The best way to improve your image SEO.
Version: 1.5
Author: Datacrypt.io - YT:@Digital-Insight
*/

// Enqueue CSS for styling
function image_alt_description_enqueue_style() {
    $screen = get_current_screen();

    // Check if the current screen is our plugin's page
    if ($screen->id === 'toplevel_page_image-alt-description') {
        wp_enqueue_style('image-alt-description-style', plugin_dir_url(__FILE__) . 'image-alt-description.css');
    }
}
add_action('admin_enqueue_scripts', 'image_alt_description_enqueue_style');


// Function to display the plugin page
function image_alt_description_page() {
    // Check user capability
    if (!current_user_can('manage_options')) {
        return;
    }

    // Handle form submissions
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'save_alt_description') {
            // Save alt description
            $image_id = absint($_POST['image_id']);
            $alt_description = sanitize_text_field($_POST['alt_description']);

            if ($image_id && $alt_description) {
                update_post_meta($image_id, '_wp_attachment_image_alt', $alt_description);
            }
        } elseif ($_POST['action'] === 'refresh_images') {
            // Refresh images
            refresh_images_without_alt_description();
        }
    }

    // Display the list of images without alt descriptions
    echo '<div class="image-alt-description-wrap">';
    display_images_without_alt_description();
    echo '</div>';
}

// Function to display the list of images without alt descriptions
function display_images_without_alt_description() {
    // Check if the function exists (for backward compatibility)
    if (!function_exists('get_images_without_alt_description')) {
        return;
    }

    $images_without_alt = get_images_without_alt_description();

    echo '<div class="wrap">';
    echo '<h1>Image Alt Description</h1>';
    
    // Display refresh button
    echo '<form method="post" action="">';
    echo '<input type="hidden" name="action" value="refresh_images">';
    echo '<input type="submit" class="button button-primary" value="Refresh">';
    echo '</form>';

    // Display the number of images without alt descriptions
    echo '<p>Number of Images without Alt Descriptions: ' . count($images_without_alt) . '</p>';

    // Display the list of images without alt descriptions
    echo '<ul>';
    foreach ($images_without_alt as $image) {
        echo '<li>';
        echo '<img src="' . esc_url($image['url']) . '" alt="Image Preview">';
        echo '<p><strong>ID:</strong> ' . $image['id'] . '</p>';
        echo '<p><strong>URL:</strong> ' . esc_url($image['url']) . '</p>';
        echo '<form method="post" action="">';
        echo '<input type="hidden" name="action" value="save_alt_description">';
        echo '<input type="hidden" name="image_id" value="' . esc_attr($image['id']) . '">';
        echo '<label for="alt_description">Alt Description:</label>';
        echo '<input type="text" name="alt_description" id="alt_description" required>';
        echo '<input type="submit" class="button" value="Save">';
        echo '</form>';
        echo '</li>';
    }
    echo '</ul>';

    echo '</div>';
}

// Function to get images without alt descriptions
function get_images_without_alt_description() {
    global $wpdb;

    $query = "SELECT ID, guid FROM {$wpdb->posts}
              WHERE post_type = 'attachment' 
              AND post_mime_type LIKE 'image%' 
              AND ID NOT IN (
                  SELECT m.post_id
                  FROM {$wpdb->postmeta} AS m
                  WHERE m.meta_key = '_wp_attachment_image_alt' AND m.meta_value != ''
              )";

    $results = $wpdb->get_results($query);

    $images_without_alt = array();
    foreach ($results as $result) {
        $images_without_alt[] = array(
            'id'  => $result->ID,
            'url' => $result->guid,
        );
    }

    return $images_without_alt;
}

// Function to refresh images without alt descriptions
function refresh_images_without_alt_description() {
    global $wpdb;

    $query = "UPDATE {$wpdb->posts} AS p
              SET p.post_modified = p.post_modified
              WHERE p.post_type = 'attachment'
              AND p.ID IN (
                  SELECT m.post_id
                  FROM {$wpdb->postmeta} AS m
                  WHERE m.meta_key = '_wp_attachment_image_alt' AND m.meta_value = ''
              )";

    $wpdb->query($query);
}

// Create the plugin page in the admin menu
function image_alt_description_menu() {
    add_menu_page('Image Alt Description', 'Image Alt Description', 'manage_options', 'image-alt-description', 'image_alt_description_page');
}
add_action('admin_menu', 'image_alt_description_menu');
